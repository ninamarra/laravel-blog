import { Component } from '@angular/core';

@Component({
  templateUrl: 'social-buttons.component.html'
})
export class SocialButtonsComponent {

  constructor() { }

}
